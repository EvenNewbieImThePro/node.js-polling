/* 
작성자: 김강범
작성일: 2019년 7월 22일 
목표: 폴링 방식으로 작동하는 1초마다 1씩 카운터가 증가하는 프로그램 작성.
폴링방식의 특징: 주기마다 데이터가 한번씩 갱신된다.
                새로고침으로 확인해야 하기 때문에 실시간으로 업데이트 되는 데이터(채팅 등)나 
                민감한 데이터를 취급하기에는 적합하지 않은 방식. 
                주기를 빠르게 하면 웹소켓과 같은 역할을 할 수 있지만 비효율적
*/

const http = require('http');
const fs = require('fs');
let number = 0;

setInterval(() => {
 number++;
}, 1000);

http.createServer((req, res) => {

    if(req.url === '/') {
        fs.readFile("./index.html", (err, data) => {
            if (err) {
                return res.end("file not exists.");
            }
            res.writeHead(200, {
                "Content-Type": "text/html; charset=utf-8"
            });
            res.end(data);
        });
    }   else if (req.url === '/api/count') {
        res.write(number + '');
        res.end();       
    }
}).listen(3000);

